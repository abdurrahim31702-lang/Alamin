import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageShell } from "./PageShell-00iCeYy8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-NFi4EvPu.js
var import_jsx_runtime = require_jsx_runtime();
function Terms() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "shell max-w-2xl pt-32 pb-24 text-ivory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "micro text-champagne",
				children: "Demo website"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-serif text-headline",
				children: "Terms"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-body font-light text-mist",
				children: "Nothing on this website is medical advice, a clinical offer, or a representation of real patient outcomes. Names, rooms, portraits and case studies are invented for a brand demonstration."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-body font-light text-mist",
				children: "Do not use this material to make treatment decisions. Consult a licensed clinician for any dental care."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "micro mt-12 inline-block text-champagne",
				children: "Return to the studio"
			})
		]
	}) });
}
//#endregion
export { Terms as component };
