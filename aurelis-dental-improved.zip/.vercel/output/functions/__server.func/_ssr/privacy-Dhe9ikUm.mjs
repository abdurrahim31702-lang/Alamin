import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageShell } from "./PageShell-00iCeYy8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-Dhe9ikUm.js
var import_jsx_runtime = require_jsx_runtime();
function Privacy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "shell max-w-2xl pt-32 pb-24 text-ivory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "micro text-champagne",
				children: "Demo website"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-serif text-headline",
				children: "Privacy"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-body font-light text-mist",
				children: "Aurelis Dental is a fictional studio created for a design demonstration. The consultation form stores a local record in your browser only. No account is created, no message is emailed, and no health information should be entered."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-body font-light text-mist",
				children: "This page exists so the footer can complete a luxury-site ritual. It is not a legal policy of a real practice."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "micro mt-12 inline-block text-champagne",
				children: "Return to the studio"
			})
		]
	}) });
}
//#endregion
export { Privacy as component };
