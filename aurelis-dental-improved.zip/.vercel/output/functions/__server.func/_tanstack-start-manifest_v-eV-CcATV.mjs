//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-eV-CcATV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/privacy",
			"/terms"
		],
		preloads: ["/assets/index-nem4B75X.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-nem4B75X.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-dA9KzSQJ.js", "/assets/PageShell-Db5Tvxfu.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-Ha7XDkjC.js", "/assets/PageShell-Db5Tvxfu.js"]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-CdOs7EpI.js", "/assets/PageShell-Db5Tvxfu.js"]
	}
} });
//#endregion
export { tsrStartManifest };
